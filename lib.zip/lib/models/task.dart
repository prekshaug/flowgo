class Task {
  final String id;
  final String title;
  final DateTime startTime;
  final String location;
  final String mood; // calm, focus, etc.
  final bool needsRoute;

  Task({
    required this.id,
    required this.title,
    required this.startTime,
    required this.location,
    required this.mood,
    required this.needsRoute,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'title': title,
      'startTime': startTime.toIso8601String(),
      'location': location,
      'mood': mood,
      'needsRoute': needsRoute,
    };
  }

  factory Task.fromMap(Map<String, dynamic> map) {
    return Task(
      id: map['id'],
      title: map['title'],
      startTime: DateTime.parse(map['startTime']),
      location: map['location'],
      mood: map['mood'],
      needsRoute: map['needsRoute'],
    );
  }
}
