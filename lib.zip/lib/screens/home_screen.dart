import 'package:flutter/material.dart';
import '../models/task.dart';
import 'add_task_screen.dart';
import 'task_detail_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final List<Task> _tasks = [
    Task(
      id: '1',
      title: 'Yoga Session',
      startTime: DateTime.now().add(Duration(hours: 1)),
      location: 'MG Road Wellness Studio',
      mood: 'calm',
      needsRoute: true,
    ),
    Task(
      id: '2',
      title: 'Work Meeting',
      startTime: DateTime.now().add(Duration(hours: 3)),
      location: 'Indiranagar Office',
      mood: 'focus',
      needsRoute: true,
    ),
  ];

  void _addNewTask(Task task) {
    setState(() {
      _tasks.add(task);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('FlowGo Planner')),
      body: ListView.builder(
        itemCount: _tasks.length,
        itemBuilder: (ctx, index) {
          final task = _tasks[index];
          return ListTile(
            leading: Icon(Icons.event_note),
            title: Text(task.title),
            subtitle: Text(
              '${task.location} • ${task.startTime.hour}:${task.startTime.minute.toString().padLeft(2, '0')}',
            ),
            trailing: task.needsRoute ? Icon(Icons.navigation) : null,
            onTap: () {
              Navigator.of(context).push(MaterialPageRoute(
                builder: (_) => TaskDetailScreen(task: task),
              ));
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.of(context).push(MaterialPageRoute(
            builder: (_) => AddTaskScreen(onAdd: _addNewTask),
          ));
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}
