import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';
import '../models/task.dart';
import 'package:url_launcher/url_launcher.dart';

class TaskDetailScreen extends StatefulWidget {
  final Task task;

  const TaskDetailScreen({super.key, required this.task});

  @override
  State<TaskDetailScreen> createState() => _TaskDetailScreenState();
}

class _TaskDetailScreenState extends State<TaskDetailScreen> {
  LatLng? _currentLatLng;
  LatLng? _destinationLatLng;
  late GoogleMapController _mapController;

  @override
  void initState() {
    super.initState();
    _fetchLocationData();
  }

  Future<void> _fetchLocationData() async {
    await Geolocator.requestPermission();
    final position = await Geolocator.getCurrentPosition();
    final placemarks = await locationFromAddress(widget.task.location);

    if (placemarks.isNotEmpty) {
      final place = placemarks.first;
      setState(() {
        _currentLatLng = LatLng(position.latitude, position.longitude);
        _destinationLatLng = LatLng(place.latitude, place.longitude);
      });
    }
  }

  void _launchMaps(String location) async {
    final encodedLocation = Uri.encodeComponent(location);
    final url = 'https://www.google.com/maps/search/?api=1&query=$encodedLocation';

    if (await canLaunchUrl(Uri.parse(url))) {
      await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    } else {
      throw 'Could not open the map.';
    }
  }

  @override
  Widget build(BuildContext context) {
    final task = widget.task;

    return Scaffold(
      appBar: AppBar(title: Text(task.title)),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: ListView(
          children: [
            Text('Location: ${task.location}', style: TextStyle(fontSize: 18)),
            SizedBox(height: 8),
            Text(
              'Start Time: ${task.startTime.hour}:${task.startTime.minute.toString().padLeft(2, '0')}',
              style: TextStyle(fontSize: 18),
            ),
            SizedBox(height: 8),
            Text('Mood: ${task.mood}', style: TextStyle(fontSize: 18)),
            SizedBox(height: 24),
            if (task.needsRoute)
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Route Preview',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  Container(
                    height: 300,
                    width: double.infinity,
                    child: _currentLatLng == null || _destinationLatLng == null
                        ? Center(child: CircularProgressIndicator())
                        : GoogleMap(
                      initialCameraPosition: CameraPosition(
                        target: _destinationLatLng!,
                        zoom: 14,
                      ),
                      markers: {
                        Marker(
                          markerId: MarkerId('current'),
                          position: _currentLatLng!,
                          infoWindow: InfoWindow(title: 'You'),
                        ),
                        Marker(
                          markerId: MarkerId('destination'),
                          position: _destinationLatLng!,
                          infoWindow: InfoWindow(title: task.location),
                        ),
                      },
                      onMapCreated: (controller) {
                        _mapController = controller;
                      },
                    ),
                  ),
                  const SizedBox(height: 12),
                  ElevatedButton.icon(
                    onPressed: () => _launchMaps(task.location),
                    icon: const Icon(Icons.navigation),
                    label: const Text('Open in Google Maps'),
                  ),
                ],
              ),
          ],
        ),
      ),
    );
  }
}
