import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:uuid/uuid.dart';
import '../models/task.dart';
import 'package:flutter_google_places/flutter_google_places.dart';
import 'package:google_maps_webservice/places.dart';
import 'package:intl/intl.dart';
import 'package:flutter_polyline_points/flutter_polyline_points.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

const kGoogleApiKey = 'AIzaSyCOMcj1GEpwcZH125EoHGPe4HzGgYTJm8k'; // Use your own

class AddTaskScreen extends StatefulWidget {
  final void Function(Task) onAdd;

  const AddTaskScreen({super.key, required this.onAdd});

  @override
  State<AddTaskScreen> createState() => _AddTaskScreenState();
}

class _AddTaskScreenState extends State<AddTaskScreen> {
  final _titleController = TextEditingController();
  final _locationController = TextEditingController();
  String _selectedMood = 'calm';
  DateTime? _selectedDateTime;
  LatLng? _currentLocation;
  LatLng? _destinationLatLng;
  GoogleMapController? _mapController;
  List<LatLng> _polylinePoints = [];

  @override
  void initState() {
    super.initState();
    _detectCurrentLocation();
  }

  Future<void> _detectCurrentLocation() async {
    final position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high);
    setState(() {
      _currentLocation = LatLng(position.latitude, position.longitude);
    });
  }
  //Future<void> _pickDestination() async {
  //   final prediction = await PlacesAutocomplete.show(
  //     context: context,
  //     apiKey: kGoogleApiKey,
  //     mode: Mode.overlay,
  //     language: 'en',
  //     components: [Component(Component.country, 'in')],
  //   );
  //
  //   if (prediction != null) {
  //     print("User selected: ${prediction.description}");
  //   } else {
  //     print("No prediction returned.");
  //   }
  // }


  // Future<void> _pickDestination() async {
  //   final prediction = await PlacesAutocomplete.show(
  //     context: context,
  //     apiKey: kGoogleApiKey,
  //     mode: Mode.overlay,
  //     language: 'en',
  //     components: [Component(Component.country, 'in')],
  //   );
  //
  //   if (prediction != null) {
  //     final places = GoogleMapsPlaces(apiKey: kGoogleApiKey);
  //     final detail = await places.getDetailsByPlaceId(prediction.placeId!);
  //     final geometry = detail.result.geometry!;
  //     setState(() {
  //       _locationController.text = prediction.description!;
  //       _destinationLatLng =
  //           LatLng(geometry.location.lat, geometry.location.lng);
  //     });
  //
  //     _getRoutePolyline(); // fetch route immediately after picking destination
  //   }
  // }
  Future<void> _pickDestination() async {
    try {
      final prediction = await PlacesAutocomplete.show(
        context: context,
        apiKey: kGoogleApiKey,
        mode: Mode.overlay,
        language: 'en',
        components: [Component(Component.country, 'in')],
      );

      if (prediction != null) {
        final places = GoogleMapsPlaces(apiKey: kGoogleApiKey);
        final detail = await places.getDetailsByPlaceId(prediction.placeId!);

        if (detail.status == "OK" && detail.result.geometry != null) {
          final geometry = detail.result.geometry!;
          setState(() {
            _locationController.text = prediction.description!;
            _destinationLatLng = LatLng(
              geometry.location.lat,
              geometry.location.lng,
            );
          });
          _getRoutePolyline(); // Fetch route
        } else {
          print("Failed to get place details: ${detail.errorMessage}");
        }
      } else {
        print("Prediction was null.");
      }
    } catch (e) {
      print("Error fetching destination: $e");
    }
  }


  void _pickDateTime() async {
    final date = await showDatePicker(
      context: context,
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 30)),
      initialDate: DateTime.now(),
    );

    if (date == null) return;

    final time = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );

    if (time == null) return;

    setState(() {
      _selectedDateTime = DateTime(
          date.year, date.month, date.day, time.hour, time.minute);
    });
  }

  Future<void> _getRoutePolyline() async {
    if (_currentLocation == null || _destinationLatLng == null) return;

    final origin =
        '${_currentLocation!.latitude},${_currentLocation!.longitude}';
    final destination =
        '${_destinationLatLng!.latitude},${_destinationLatLng!.longitude}';
    final url =
        'https://maps.googleapis.com/maps/api/directions/json?origin=$origin&destination=$destination&key=$kGoogleApiKey';

    final response = await http.get(Uri.parse(url));
    final data = json.decode(response.body);

    if (data['routes'].isNotEmpty) {
      final points = data['routes'][0]['overview_polyline']['points'];
      final polylinePoints = PolylinePoints().decodePolyline(points);

      setState(() {
        _polylinePoints =
            polylinePoints.map((e) => LatLng(e.latitude, e.longitude)).toList();
      });
    }
  }

  void _submit() {
    if (_titleController.text.isEmpty ||
        _locationController.text.isEmpty ||
        _selectedDateTime == null ||
        _currentLocation == null ||
        _destinationLatLng == null) return;

    final task = Task(
      id: const Uuid().v4(),
      title: _titleController.text,
      location: _locationController.text,
      startTime: _selectedDateTime!,
      mood: _selectedMood,
      needsRoute: true,
    );

    widget.onAdd(task);
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Create Task')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: _titleController,
              decoration: const InputDecoration(labelText: 'Task Title'),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _locationController,
              readOnly: true,
              onTap: _pickDestination,
              decoration: const InputDecoration(labelText: 'Destination'),
            ),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: _pickDateTime,
              child: Text(_selectedDateTime == null
                  ? 'Pick Date & Time'
                  : DateFormat.yMMMd().add_jm().format(_selectedDateTime!)),
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              value: _selectedMood,
              decoration: const InputDecoration(labelText: 'Mood'),
              items: ['calm', 'focus', 'energized'].map((mood) {
                return DropdownMenuItem(value: mood, child: Text(mood));
              }).toList(),
              onChanged: (val) => setState(() => _selectedMood = val!),
            ),
            const SizedBox(height: 20),
            if (_currentLocation != null && _destinationLatLng != null)
              Container(
                height: 220,
                margin: const EdgeInsets.only(bottom: 20),
                child: GoogleMap(
                  initialCameraPosition: CameraPosition(
                    target: _currentLocation!,
                    zoom: 13,
                  ),
                  myLocationEnabled: true,
                  markers: {
                    Marker(
                      markerId: const MarkerId('origin'),
                      position: _currentLocation!,
                      infoWindow: const InfoWindow(title: 'Your Location'),
                    ),
                    Marker(
                      markerId: const MarkerId('destination'),
                      position: _destinationLatLng!,
                      infoWindow: const InfoWindow(title: 'Destination'),
                    ),
                  },
                  polylines: {
                    if (_polylinePoints.isNotEmpty)
                      Polyline(
                        polylineId: const PolylineId('route'),
                        color: Colors.blue,
                        width: 5,
                        points: _polylinePoints,
                      ),
                  },
                  onMapCreated: (controller) {
                    _mapController = controller;
                  },
                ),
              ),
            ElevatedButton.icon(
              onPressed: _submit,
              icon: const Icon(Icons.check),
              label: const Text('Done'),
              style: ElevatedButton.styleFrom(
                  minimumSize: const Size.fromHeight(45)),
            ),
          ],
        ),
      ),
    );
  }
}
